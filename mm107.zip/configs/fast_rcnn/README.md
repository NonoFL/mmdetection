# Fast R-CNN

## Introduction

<!-- [ALGORITHM] -->

```latex
@inproceedings{girshick2015fast,
  title={Fast r-cnn},
  author={Girshick, Ross},
  booktitle={Proceedings of the IEEE international conference on computer vision},
  year={2015}
}
```

## Results and models
